/*
@license

dhtmlxGantt v.4.2.1 Professional Evaluation
This software is covered by DHTMLX Evaluation License. Contact sales@dhtmlx.com to get Commercial or Enterprise license. Usage without proper license is prohibited.

(c) Dinamenta, UAB.
*/


Useful links
-------------

- Online  documentation
	https://docs.dhtmlx.com/gantt/

- Downloadable documentation
	CHM version
		https://docs.dhtmlx.com/chm/gantt.chm.zip
	HTML version
		http://dhtmlx.com/x/download/regular/dhtmlxgantt_docs_html.zip
	
- Support forum
	https://forum.dhtmlx.com/viewforum.php?f=15