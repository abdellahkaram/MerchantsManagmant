<html>
<head>
</head>


<body>

<h1>Hello World</h1>
<a href="{{ route('sendEmail ') }}">Send Email</a>


</body>


</html>