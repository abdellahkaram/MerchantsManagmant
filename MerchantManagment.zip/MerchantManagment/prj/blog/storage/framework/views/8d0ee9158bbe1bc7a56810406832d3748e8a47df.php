<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet"   href="<?php echo e(asset('css/newKanban.css')); ?> ">
        <link rel="stylesheet"   href="<?php echo e(asset('css/nav.css')); ?> ">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.1/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
        <?php echo $__env->make('nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                                <div class-"container-fluid">
                                                
                                    <div class="col-md-12 text-center">
                                         <img src="image/kanban.png"  height="40px" width="40px" alt="">
                                            <p id="kanban_title">Edit Project</p>
                                            <p id="keep">Keep a constant workflow on independent tasks</p>
                                        </div>

                                        <div class="col-md-12">


         
        
            


      	<?php echo Form::model($project, ['route' => ['project.update', $project->id], 'method' => 'PUT']); ?>

        <div class="form-group">
				<?php echo e(Form::label('name', 'Project name:'  )); ?>

				<?php echo e(Form::text('name', $project->name , array('class' => 'form-control', 'required' => '', 'maxlength' => '255' ))); ?>

        </div>
        <div class="form-group">
				<?php echo e(Form::label('description', "Project Description:")); ?>

				<?php echo e(Form::textarea('description', $project->description, array('class' => 'form-control'))); ?>

        </div>
        
        <div class="form-group">
          <?php echo e(Form::select('state', array('working_on'  => 'working_on', 'closed' => 'closed'), null, array('class' => 'form-control'))); ?>

        </div>


        <?php echo e(Form::reset('BACK', array('class' => 'col-md-3  btn_submit'))); ?>

				<?php echo e(Form::submit('Update Project', array('class' => 'col-md-7 col-md-offset-2  btn_submit'))); ?>

			<?php echo Form::close(); ?>












          </div>
    </div>











                            </body>
</html>