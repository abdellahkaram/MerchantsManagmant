<?php $__env->startComponent('mail::message'); ?>
# Welcome To Casamerchants

Bonjour ,
De Nouveau Tache Vous a etè Assignie Dans MerchantManagment
<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:8000/']); ?>
Login in to MerchantManagment
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
