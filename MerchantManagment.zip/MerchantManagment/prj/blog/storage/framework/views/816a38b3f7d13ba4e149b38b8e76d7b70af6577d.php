<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet"   href="<?php echo e(asset('css/newKanban.css')); ?> ">
        <link rel="stylesheet"   href="<?php echo e(asset('css/kanban.css')); ?> ">
        <link rel="stylesheet"   href="<?php echo e(asset('css/nav.css')); ?> ">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.1/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
    
    <?php echo $__env->make('nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 


                                <div class-"container-fluid">
                                                
                                    <div class="col-md-12 text-center">
                                         <img src="image/kanban.png"  height="40px" width="40px" alt="">
                                            <p id="kanban_title">New Task</p>
                                            <p id="keep">Keep a constant workflow on independent tasks</p>
                                        </div>

                                        <div class="col-md-12">


         
        
            


     








        <?php echo Form::open(array('route' => 'task.store', 'data-parsley-validate' => '' , 'class'=>'col-md-8 col-md-offset-2')); ?>

        <div class="form-group">
				<?php echo e(Form::label('name', 'Task name:'  )); ?>

				<?php echo e(Form::text('name', null, array('class' => 'form-control', 'required' => '', 'maxlength' => '255' ))); ?>

        </div>
        <div class="form-group">
				<?php echo e(Form::label('desciption', "Task Description:")); ?>

				<?php echo e(Form::text('desciption','default desc ' , array('class' => 'form-control'))); ?>

        </div> 


        <div class="form-group">
        <?php echo e(Form::label('state', 'state:'  )); ?>

         <?php echo e(Form::select('state', array( 'planifie' => 'planifie' ,'encours' => 'encours' , 'compelte' => 'compelte' , 'annule' => 'annule'), null, array('class' => 'form-control'))); ?>

        </div>

        <div class="form-group">
				<?php echo e(Form::label('comment', 'comment:'  )); ?>

				<?php echo e(Form::text('comment', null, array('class' => 'form-control', 'required' => '', 'maxlength' => '255' ))); ?>

        </div>

         <div class="form-group">
				<?php echo e(Form::label('execution_date', 'Date Execution:'  )); ?>

                <?php echo e(Form::date('execution_date', \Carbon\Carbon::now()) , array('class' => 'form-control', 'required' => '' )); ?>

        </div>

        <div class="form-group">
				<?php echo e(Form::label('delay', 'Delay:'  )); ?>

				<?php echo e(Form::text('delay', null, array('class' => 'form-control', 'required' => '', 'maxlength' => '255' ))); ?>

        </div>


         <div class="form-group">
				<?php echo e(Form::label('project_id', 'project_id:'  ,  array('class' => 'hidden')  )); ?>

				<?php echo e(Form::text('project_id', $coll['projectid'], array('class' => 'form-control  hidden', 'required' => '', 'maxlength' => '255'  ))); ?>

        </div>

        <div class="form-group" >
        <label>Assigned :</label>
            <select name="emp[]" class="form-control" multiple>
             <?php $__currentLoopData = $coll['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small><b>Hold Shift + Ctrl<b></small>
        </div>





        <?php echo e(Form::reset('BACK', array('class' => 'col-md-3  btn_submit'))); ?>

				<?php echo e(Form::submit('Create Task', array('class' => 'col-md-7 col-md-offset-2  btn_submit'))); ?>

			<?php echo Form::close(); ?>







          </div>
    </div>











                            </body>
</html>